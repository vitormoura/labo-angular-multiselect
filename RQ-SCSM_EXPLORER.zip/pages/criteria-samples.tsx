import { GetStaticProps } from "next";
import Link from "next/link";
import { Card, Container } from "react-bootstrap";

export default function CriteriaSamplesPage(props) {
  return (
    <Container>
      <h1 className="page-title">Exemples de Criteria XML</h1>

      <Card className="app-page-content-card">
        <Card.Body>
          <section className="page-content-section">
            <h4>Avant commencer</h4>

            <p>
              Il faut trouver les références XML des
              propriétés et Management Packs utilisés dans notre catalogue afin de les remplacer sur
              les expressions exemple suivantes.
            </p>
          </section>

          <hr />

          <section className="page-content-section">
            <h5>Filtre par propriété de l'objet racine dans une Projection</h5>

            <small>
              <pre>
                {`<Criteria xmlns=""http://Microsoft.EnterpriseManagement.Core.Criteria/"">
    <Reference Id='System.Library' Version='7.5.2905.0' PublicKeyToken='31bf3856ad364e35' Alias='SL' />
    <Expression>                                            
        <SimpleExpression>
            <ValueExpressionLeft>
                <Property>$Context/Property[Type='SL!System.User']/City$</Property>
            </ValueExpressionLeft>
            <Operator>Like</Operator>
            <ValueExpressionRight>
                <Value>Qu%</Value>
            </ValueExpressionRight>
        </SimpleExpression>
    </Expression>
</Criteria>`}
              </pre>
            </small>

            <h5>
              Filtre par propriété d'un objet membre d'une relation dans une
              Projection
            </h5>

            <small>
              <pre>
                {`<Criteria xmlns=""http://Microsoft.EnterpriseManagement.Core.Criteria/"">
    <Reference Id='CiresonAssetManagement' Version='8.3.1.2016' PublicKeyToken='98ba2176e2a9efbc' Alias='CAM' />
    <Reference Id='System.Library' Version='7.5.8501.1' PublicKeyToken='31bf3856ad364e35' Alias='SLIB' />
    <Expression>                                            
        <SimpleExpression>
            <ValueExpressionLeft>
                <Property>$Context/Path[Relationship='CAM!Cireson.AssetManagement.HardwareAssetHasPrimaryUser' TypeConstraint='SLIB!System.Domain.User']/Property[Type='SLIB!System.Domain.User']/UserName$</Property>
            </ValueExpressionLeft>
            <Operator>Like</Operator>
            <ValueExpressionRight>
                <Value>RDEV021</Value>
            </ValueExpressionRight>
        </SimpleExpression>
    </Expression>
</Criteria>`}
              </pre>
            </small>

            <h5>Filtre objet racine par identifiant FullName</h5>
            <small>
              <pre>
                {`<Criteria xmlns=""http://Microsoft.EnterpriseManagement.Core.Criteria/"">
    <Expression>                                            
        <SimpleExpression>
            <ValueExpressionLeft>
                <GenericProperty>FullName</GenericProperty>
            </ValueExpressionLeft>
            <Operator>Equal</Operator>
            <ValueExpressionRight>
                <Value>System.Domain.User:PROD.RDEV021</Value>
            </ValueExpressionRight>
        </SimpleExpression>
    </Expression>
</Criteria>`}
              </pre>
            </small>

    <h5>Filtre propriété d'objet racine et aussi par des propriétés dans ses relations</h5>
    <small>
      <pre>
        {`<Criteria xmlns=""http://Microsoft.EnterpriseManagement.Core.Criteria/"">
    <Reference Id='CiresonAssetManagement' Version='8.3.1.2016' PublicKeyToken='98ba2176e2a9efbc' Alias='MP00042' />
    <Expression>
        <And>
            <Expression>                                            
                <SimpleExpression>
                    <ValueExpressionLeft>
                        <GenericProperty>FullName</GenericProperty>
                    </ValueExpressionLeft>
                    <Operator>Equal</Operator>
                    <ValueExpressionRight>
                        <Value>System.Domain.User:PROD.RPOJ044</Value><!-- Utilisateur specifique -->
                    </ValueExpressionRight>
                </SimpleExpression>
            </Expression>
            <Expression>      
                <SimpleExpression>
                    <ValueExpressionLeft>
                        <Property>$Context/Path[Relationship='MP00042!Cireson.AssetManagement.HardwareAssetHasPrimaryUser' SeedRole='Target' TypeConstraint='MP00042!Cireson.AssetManagement.HardwareAsset']/Property[Type='MP00042!Cireson.AssetManagement.HardwareAsset']/HardwareAssetStatus$</Property>
                    </ValueExpressionLeft>
                    <Operator>Equal</Operator>
                    <ValueExpressionRight>
                        <Value>514febe9-f847-a975-f1a0-b9c164249c0d</Value><!-- Qui a des HardwareAssets avec le statut 'En utilisation' -->
                    </ValueExpressionRight>
                </SimpleExpression>
            </Expression>
            <Expression>
                <SimpleExpression>
                    <ValueExpressionLeft>
                        <Property>$Context/Path[Relationship='MP00042!Cireson.AssetManagement.HardwareAssetHasPrimaryUser' SeedRole='Target' TypeConstraint='MP00042!Cireson.AssetManagement.HardwareAsset']/Property[Type='MP00042!Cireson.AssetManagement.HardwareAsset']/HardwareAssetType$</Property>
                    </ValueExpressionLeft>
                    <Operator>Equal</Operator>
                    <ValueExpressionRight>
                        <Value>3c3e5911-9705-0daa-c1ea-1b8915d8557d</Value>
                    </ValueExpressionRight><!-- et qui a des HardwareAssets avec le type 'PC de Table' -->
                </SimpleExpression>
            </Expression>
        </And>
    </Expression>
</Criteria>`}
      </pre>
    </small>

          </section>
        </Card.Body>
      </Card>
    </Container>
  );
}

export const getStaticProps: GetStaticProps = async ({ params }) => {
  return {
    props: {
      title: "Criteria Samples",
    },
  };
};

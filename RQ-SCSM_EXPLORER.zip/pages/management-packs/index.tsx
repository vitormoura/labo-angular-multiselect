import { GetStaticPaths, GetStaticProps } from "next";
import { Container, Card, ListGroup } from "react-bootstrap";
import { recupererManagementPacks } from "../../lib/static-data-loader";
import { IManagementPack } from "../../lib/static-data-models";
import Link from "next/link";
import { OrderBy } from "@/lib/ui-utils";

type PageProps = {
  managementPacks: IManagementPack[];
};

export default function ManagementPackListPage({ managementPacks }: PageProps) {
  return (
    <Container>
      <h1 className="page-title">Management Packs</h1>

      <Card className="app-page-content-card">
        <Card.Body>
          <section className="page-content-section liste-elements">
            <ul>
              {managementPacks
                .sort(OrderBy.localeCompare("Name"))
                .map((mp, index) => (
                  <li key={mp.ID}>
                    <span className="index-label">{index + 1}.</span>
                    <Link href={`/management-packs/${mp.ID}`}>
                      <a>{mp.Name}</a>
                    </Link>
                  </li>
                ))}
            </ul>
          </section>
        </Card.Body>
      </Card>
    </Container>
  );  
}

/////////////////////////////////////

export const getStaticProps: GetStaticProps = async (context) => {
  const managementPacks = await recupererManagementPacks();

  return {
    props: {
      title: "Management Packs",
      managementPacks,
    } as PageProps,
  };
};

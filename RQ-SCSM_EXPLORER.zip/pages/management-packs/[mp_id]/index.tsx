import Link from "next/link";
import { GetStaticProps, GetStaticPaths } from "next";
import { Nav, Card, Accordion } from "react-bootstrap";
import {
  recupererInfoManagementPackParId,
  recupererManagementPacks,
} from "@/lib/static-data-loader";
import {
  IDetailedManagementPack,
  IManagementPackObjectType,
} from "@/lib/static-data-models";
import { OrderBy } from "@/lib/ui-utils";
import { CopyButton } from "@/components/copy-to-clipboard";
import { BookmarkButton } from "@/components/bookmark-button";

type PageProps = {
  managementPack: IDetailedManagementPack;
};

export default function ManagementPackDetailsPage({
  managementPack,
}: PageProps) {
  const sections = ["Classes", "Enumerations", "TypeProjections"];
  const sectionsToShow = sections
    .map((x) => ({
      name: x,
      length: Object.keys(managementPack.Objects[x]).length,
    }))
    .filter((x) => x.length > 0);

  return (
    <>
      <h1 className="page-title">
        {managementPack.FriendlyName}

        <BookmarkButton
          entityId={managementPack.ID}
          url={`/management-packs/${managementPack.ID}`}
          name={managementPack.Name}
          type="Management Pack"
        />
      </h1>

      {sectionsToShow.length > 0 ? (
        <Card className="app-page-content-card">
          <Card.Body>
            <section className="page-content-section">
              <h5>Informations générales</h5>

              <dl>
                <dt>
                  Identifiant <CopyButton text={managementPack.ID} />
                </dt>
                <dd>{managementPack.ID}</dd>

                <dt>Nom</dt>
                <dd>{managementPack.Name}</dd>

                <dt>Friendly Name</dt>
                <dd>{managementPack.FriendlyName}</dd>

                <dt>Version</dt>
                <dd>{managementPack.Version}</dd>

                <dt>KeyToken</dt>
                <dd>{managementPack.KeyToken}</dd>

                <dt>
                  Référence Xml Criteria{" "}
                  <CopyButton text={managementPack.XmlReferenceSample} />
                </dt>
                <dd>{managementPack.XmlReferenceSample}</dd>
              </dl>
            </section>

            <Accordion className="accordion-list-objects">
              {sections.map((section, index) => (
                <SectionBlock
                  mpID={managementPack.ID}
                  type={section}
                  items={
                    managementPack.Objects[
                      section
                    ] as IManagementPackObjectType[]
                  }
                  key={index}
                />
              ))}
            </Accordion>
          </Card.Body>
        </Card>
      ) : (
        <p>Aucun élément à afficher</p>
      )}
    </>
  );
}

const SectionBlock = (props: {
  mpID: string;
  type: string;
  items: IManagementPackObjectType[];
}) => {
  if (props.items.length === 0) {
    return null;
  }

  return (
    <Card key={props.type}>
      <Accordion.Toggle as={Card.Header} eventKey={props.type}>
        <strong>
          {props.type} ({props.items.length})
        </strong>
      </Accordion.Toggle>
      <Accordion.Collapse eventKey={props.type}>
        <Card.Body>
          <section className="page-content-section liste-elements">
            <ul>
              {props.items
                .sort(OrderBy.localeCompare("Name"))
                .map((c, index) => (
                  <li key={c.ID}>
                    <span className="index-label">{index + 1}.</span>
                    <Link
                      href={`/management-packs/${
                        props.mpID
                      }/${props.type.toLocaleLowerCase()}/${c.ID}`}
                    >
                      <a>{c.Name}</a>
                    </Link>
                  </li>
                ))}
            </ul>
          </section>
        </Card.Body>
      </Accordion.Collapse>
    </Card>
  );
};

///////////////////////

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const mpId = params.mp_id as string;
  const mp = await recupererInfoManagementPackParId(mpId);

  return {
    props: {
      title: mp.Name,
      mp_id: mp.ID,
      mp_name: mp.Name,
      managementPack: mp,
    },
  };
};

export const getStaticPaths: GetStaticPaths = async () => {
  const managementPacks = await recupererManagementPacks();
  const paths = managementPacks.map((mp) => `/management-packs/${mp.ID}`);

  return { paths, fallback: false };
};

//////////////////////

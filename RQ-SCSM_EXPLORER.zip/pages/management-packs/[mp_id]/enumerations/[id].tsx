import {
  recupererElementsEnumParId,
  recupererListeTypesObject,
} from "@/lib/static-data-loader";
import { GenericPageProps, IEnumerationItem } from "@/lib/static-data-models";
import { GetStaticPaths, GetStaticProps } from "next";
import { Card, Table } from "react-bootstrap";
import { CopyButton } from "@/components/copy-to-clipboard";
import { BookmarkButton } from "@/components/bookmark-button";

interface PageProps extends GenericPageProps {
  id: string;
  elements: IEnumerationItem[];
}

export default function PageEnumerationDetails({
  id,
  mp_id,
  elements,
}: PageProps) {
  var root = elements[0];

  return (
    <>
      <h1 className="page-title">
        {root.Name}

        <BookmarkButton
          entityId={root.ID}
          url={`/management-packs/${mp_id}/enumerations/${id}`}
          name={root.Name}
          type="Enumerations"
        />
      </h1>

      <Card className="app-page-content-card">
        <Card.Body>
          <section className="page-content-section">
            <h5>Informations générales</h5>

            <dl>
              <dt>
                Identifiant <CopyButton text={root.ID} />
              </dt>
              <dd>{root.ID}</dd>

              <dt>Nom</dt>
              <dd>{root.Name}</dd>

              <dt>Description</dt>
              <dd>{root.Description || "-"}</dd>
            </dl>
          </section>

          <section className="page-content-section">
            <h5>Éléments de l'enumeration</h5>

            <Table responsive hover size="sm">
              <tbody>
                {elements.map((e, index) => (
                  <tr key={e.ID}>
                    <td
                      style={{
                        paddingLeft: `${(e.Level + 1) * 1}rem`,
                        fontWeight: 900 - (e.Level + 1) * 150,
                      }}
                    >
                      {e.DisplayName} {e.ID === root.ID ? "(racine)" : ""}
                    </td>
                    <td>{e.Name}</td>

                    <td className="table-copy-col">
                      <CopyButton text={e.ID} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </section>
        </Card.Body>
      </Card>
    </>
  );
}

///////////////////////////////////////////

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const elements = await recupererElementsEnumParId(params.id as string);

  return {
    props: {
      id: params.id,
      mp_id: params.mp_id,
      object_type: "enumerations",
      object_name: elements[0].Name,
      elements,
    },
  };
};

export const getStaticPaths: GetStaticPaths = async () => {
  const enums = await recupererListeTypesObject("ENUM");

  const paths = enums.map(
    (e) => `/management-packs/${e.ManagementPackID}/enumerations/${e.ID}`
  );

  return {
    paths,
    fallback: false,
  };
};

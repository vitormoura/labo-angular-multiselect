import {
  recupererClassDetaileeParId,
  recupererListeTypesObject,
} from "@/lib/static-data-loader";
import { GenericPageProps, IDetailedClass } from "@/lib/static-data-models";
import { GetStaticPaths, GetStaticProps } from "next";
import { Card } from "react-bootstrap";

import { CopyButton } from "@/components/copy-to-clipboard";
import { PropertyList } from "@/components/class-property-list";
import { ClassHeritageList } from "@/components/class-list";
import { CriteriaQuerySampleForClasses } from "@/components/criteria-query-sample";
import { ExternalLinkIcon } from "@/components/external-link-icon";
import { BookmarkButton } from "@/components/bookmark-button";
import Link from "next/link";

interface PageProps extends GenericPageProps {
  id: string;
  classe: IDetailedClass;
}

export default function PageClassDetails({ classe }: PageProps) {
  return (
    <>
      <h1 className="page-title">
        {classe.Name}

        <BookmarkButton
          entityId={classe.ID}
          url={`/management-packs/${classe.ManagementPackID}/classes/${classe.ID}`}
          name={classe.Name}
          type="Classes"
        />
      </h1>

      <Card className="app-page-content-card">
        <Card.Body>
          <section className="page-content-section">
            <h5>Informations générales</h5>

            <dl>
              <dt>
                Identifiant <CopyButton text={classe.ID} />
              </dt>
              <dd>{classe.ID}</dd>

              <dt>Nom</dt>
              <dd>{classe.Name}</dd>

              <dt>Management Pack</dt>
              <dd>
                <Link href={`/management-packs/${classe.ManagementPackID}`}>
                  <a target="_blank">
                    {classe.ManagementPackName} <ExternalLinkIcon />
                  </a>
                </Link>
              </dd>

              <dt>Description</dt>
              <dd>{classe.Description || "-"}</dd>

              <dt>Abstraite</dt>
              <dd>{classe.IsAbstract ? "Oui" : "Non"} *</dd>
            </dl>
          </section>

          <PropertyList title="Propriétés" classe={classe} />

          <ClassHeritageList
            title={"Classes base"}
            types={classe.ParentTypes}
            orderByName={false}
          />

          <ClassHeritageList
            title={"Classes derivées"}
            types={classe.DerivedTypes}
            orderByName={true}
          />

          <CriteriaQuerySampleForClasses classe={classe} />
        </Card.Body>
      </Card>
    </>
  );
}

///////////////////////////////////////////

export const getStaticProps: GetStaticProps = async ({ params }) => {
  var cl = await recupererClassDetaileeParId(params.id as string);
  return {
    props: {
      id: params.id,
      mp_id: params.mp_id,
      object_type: "classes",
      object_name: cl.Name,
      classe: cl,
    },
  };
};

export const getStaticPaths: GetStaticPaths = async () => {
  const classes = await recupererListeTypesObject("CLASS");

  const paths = classes.map(
    (e) => `/management-packs/${e.ManagementPackID}/classes/${e.ID}`
  );

  return {
    paths,
    fallback: false,
  };
};

import { Breadcrumb, Container, Nav, Navbar } from "react-bootstrap";

import "bootstrap/dist/css/bootstrap.min.css";
import "../styles/globals.css";
import React from "react";
import Link from "next/link";
import { GenericPageProps } from "@/lib/static-data-models";

interface GlobalPageProps {
  Component: any;
  pageProps: GenericPageProps;
}

function MyApp({ Component, pageProps }: GlobalPageProps) {
  const APP_NAME = "SCSM Entity Explorer";

  return (
    <>
      <header>
        <Navbar fixed="top" className="nav-app">
          <Container>
            <Navbar.Brand href="/">
              <img src={"/rq-logo.svg"} width="64" height="64" />
              <span className="app-name">{APP_NAME}</span>
            </Navbar.Brand>

            <Nav>
              <Link href={"/"}>
                <a className="nav-link">Home</a>
              </Link>

              <Link href={"/management-packs"}>
                <a className="nav-link">Management Packs</a>
              </Link>

              <Link href={"/search"}>
                <a className="nav-link">Search Entities</a>
              </Link>

              <Link href={"/bookmarks"}>
                <a className="nav-link">Bookmarks</a>
              </Link>

              <Link href={"/downloads/SCSMLabs.zip"}>
                <a className="nav-link">SCSMLabs</a>
              </Link>
            </Nav>
          </Container>
        </Navbar>

        {pageProps.mp_id && (
          <Container>
            <Breadcrumb className="cnt-breadcrumb">
              <Breadcrumb.Item>
                <Link href={"/"}>
                  <a>Home</a>
                </Link>
              </Breadcrumb.Item>

              <Breadcrumb.Item>
                <Link href={`/management-packs`}>
                  <a>Management packs</a>
                </Link>
              </Breadcrumb.Item>
              <Breadcrumb.Item active={!pageProps.object_type}>
                <Link href={`/management-packs/${pageProps.mp_id}`}>
                  <a>{pageProps.mp_id}</a>
                </Link>
              </Breadcrumb.Item>

              {pageProps.id && pageProps.object_type && (
                <Breadcrumb.Item active>
                  <Link
                    href={`/management-packs/${pageProps.mp_id}/${pageProps.object_type}/${pageProps.id}`}
                  >
                    <a>{pageProps.object_name}</a>
                  </Link>
                </Breadcrumb.Item>
              )}
            </Breadcrumb>
          </Container>
        )}
      </header>

      <main className="app-page-content">
        <Container>
          <Component {...pageProps} />
        </Container>
      </main>

      <footer>
        <Container>
          <p>
            {APP_NAME} - Revenu Québec &copy;, {new Date().getFullYear()}
          </p>
          <p>
            Icons made by{" "}
            <a
              href="https://www.flaticon.com/authors/pixel-perfect"
              title="Pixel perfect"
            >
              Pixel perfect
            </a>{" "}
            from{" "}
            <a href="https://www.flaticon.com/" title="Flaticon">
              www.flaticon.com
            </a>
          </p>
        </Container>
      </footer>
    </>
  );
}

export async function getStaticProps() {
  return {
    props: {},
  };
}

export default MyApp;

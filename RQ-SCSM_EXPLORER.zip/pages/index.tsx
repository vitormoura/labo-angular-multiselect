import { GetStaticProps } from "next";
import Link from "next/link";

export default function Home(props) {
  return (
    <>
      <div className="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center">
        <div className="p-lg-5 mx-auto">
          <h1 className="display-3">SCSM Entity Explorer</h1>
          <p className="lead fw-normal p-md-3">
            Trouver des choses dans SCSM n'est pas toujours facile. Ce site
            est là pour t'aider! On y va?
          </p>

          <Link href="/search">
            <a className="btn btn-outline-secondary">Rechercher entités</a>
          </Link>
        </div>
      </div>
    </>
  );
}

export const getStaticProps: GetStaticProps = async ({ params }) => {
  return {
    props: {
      title: "SCSM Explorer",
    },
  };
};

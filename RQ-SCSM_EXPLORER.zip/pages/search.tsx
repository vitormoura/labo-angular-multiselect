import { recupererListeEntreesIndexRecherche } from "@/lib/static-data-loader";
import { ISearchIndexEntry } from "@/lib/static-data-models";
import { GetStaticProps } from "next";
import { ExternalLinkIcon } from "@/components/external-link-icon";
import {
  InputGroup,
  FormControl,
  Badge,
  Card,
  Container,
  ListGroup,
  Button,
  Row,
  Col,
} from "react-bootstrap";
import lunr from "lunr";
import { useState, useEffect } from "react";
import Link from "next/link";
import { OrderBy } from "@/lib/ui-utils";

let searchIndex = null;

type SearchObjectsPageProps = {
  searchableItems: ISearchIndexEntry[];
};

function SearchResultItem({
  item,
  score,
}: {
  item: ISearchIndexEntry;
  score: number;
}) {
  const typeColor = {
    CLASS: "primary",
    ENUM: "info",
    TYPE_PROJ: "success",
    MP: "danger",
    TYPE_PROJ_COMP: "warning",
  };
  const mapTypeObject = {
    CLASS: "classes",
    ENUM: "enumerations",
    TYPE_PROJ: "typeprojections",
    MP: "",
    TYPE_PROJ_COMP: "typeprojections",
  };

  if (!item) {
    return null;
  }

  let link = `/management-packs/${item.ManagementPackID}`;

  if (item.Type !== "MP") {
    link = `${link}/${mapTypeObject[item.Type]}/${item.ID}`;
  }

  return (
    <ListGroup.Item>
      <Row>
        <Col md={1}>
          <Badge
            variant={typeColor[item.Type] || "dark"}
            className="badge-type"
          >
            {item.Type.substr(0, 2)}
          </Badge>
        </Col>
        <Col>
          <>
            <strong>
              <Link href={link}>
                <a target="_blank">{item.Name}</a>
              </Link>
            </strong>{" "}
            <br />
            {item.DisplayName}
          </>
        </Col>
      </Row>
    </ListGroup.Item>
  );
}

export default function SearchObjectsPage({
  searchableItems,
}: SearchObjectsPageProps) {
  if (!searchableItems) {
    return null;
  }

  const [indexReady, setIndexReady] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState({
    searchCriteria: "",
    items: [] as { ref: number }[],
  });

  useEffect(() => {
    searchIndex = lunr(function () {
      this.ref("Position");
      this.field("SearchText");

      searchableItems.forEach(function (e) {
        this.add(e);
      }, this);

      setIndexReady(true);
    });
  }, []);

  if (!indexReady) {
    return null;
  }

  const runSearch = () => {
    const newSearchTerm = searchTerm.trim();

    if (
      newSearchTerm.length > 2 &&
      searchResults.searchCriteria !== newSearchTerm
    ) {
      const results = searchIndex.search(newSearchTerm);
      setSearchResults({ searchCriteria: newSearchTerm, items: results });
    }
  };

  const setSearchCriteria = (text) => {
    setSearchTerm(text);
  };

  return (
    <Container>
      <h1 className="page-title">Search Entities</h1>

      <Container>
        <section className="page-content-section">
          <label htmlFor="basic-url">
            Management Pack, Classes, Type Projections et Enumerations
          </label>
          <InputGroup className="mb-3">
            <FormControl
              id="search-objects"
              aria-describedby="label-search-objects"
              onChange={(e) => setSearchCriteria(e.target.value)}
              onKeyPress={(e) => (e.charCode === 13 ? runSearch() : null)}
              placeholder="Nom, Description ou Identitiant GUID"
            />

            <InputGroup.Append>
              <Button variant="outline-secondary" onClick={() => runSearch()}>
                Search
              </Button>
            </InputGroup.Append>
          </InputGroup>

          <p>
            <em>
              Wildcards: foo* (contenant qq texte), +foo bar -baz (contenant
              'foo' et 'bar', pas 'baz')
            </em>
          </p>
        </section>
      </Container>

      {searchResults.searchCriteria && (
        <Card className="app-page-content-card">
          <Card.Body>
            <div className="cnt-search-result">
              <section className="page-content-section">
                <h5>
                  Résultats ({searchResults.items.length}) : "
                  {searchResults.searchCriteria}"
                </h5>

                <ListGroup className="cnt-items" variant="flush">
                  {searchResults.items
                    .map((r) => searchableItems[r.ref])
                    .sort(OrderBy.localeCompare("Type"))
                    .map((r) => (
                      <SearchResultItem item={r} score={0} />
                    ))}
                </ListGroup>
              </section>
            </div>
          </Card.Body>
        </Card>
      )}
    </Container>
  );
}

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const searchIndexEntries = await recupererListeEntreesIndexRecherche();

  return {
    props: {
      searchableItems: searchIndexEntries,
    },
  };
};

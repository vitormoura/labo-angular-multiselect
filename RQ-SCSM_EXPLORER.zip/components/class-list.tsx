import { IBaseClass } from "@/lib/static-data-models";
import { OrderBy } from "@/lib/ui-utils";
import Link from "next/link";

export function ClassHeritageList({
  title,
  types,
  orderByName,
}: {
  title: string;
  types: IBaseClass[];
  orderByName: boolean;
}) {
  let el = null;

  if (!types || types.length == 0) {
    el = <p>Aucun élément</p>;
  } else {
    types = orderByName ? types.sort(OrderBy.localeCompare("Name")) : types;

    el = (
      <ul>
        {types.map((c, index) => (
          <li key={c.ID}>
            <span className="index-label">{index + 1}.</span>
            <Link
              href={`/management-packs/${c.ManagementPackID}/classes/${c.ID}`}
            >
              <a>
                {c.Name} {c.IsAbstract ? "(a)" : ""}
              </a>
            </Link>
          </li>
        ))}
      </ul>
    );
  }

  return (
    <section className="page-content-section">
      <h5>{title}</h5>
      {el}
    </section>
  );
}

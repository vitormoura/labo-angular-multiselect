import { IDetailedClass } from "@/lib/static-data-models";
import { OrderBy } from "@/lib/ui-utils";
import { Table } from "react-bootstrap";
import { CopyButton } from "@/components/copy-to-clipboard";
import { ExternalLinkIcon } from "@/components/external-link-icon";
import Link from "next/link";
import groupBy from "lodash/groupBy";

export function PropertyList({
  title,
  classe,
}: {
  title: string;
  classe: IDetailedClass;
}) {
  const hasProperties = classe.Properties && classe.Properties.length > 0;

  const propsByClass = groupBy(classe.Properties, "ClassID");
  const parentsById = Object.assign(
    { [classe.ID]: classe },
    ...classe.ParentTypes.map((p) => ({ [p.ID]: p }))
  );
  const classHierachyOrder = classe.ParentTypes.map((p) => p.ID);
  classHierachyOrder.push(classe.ID);

  let globalIndex = 1;

  return (
    <>
      {hasProperties && (
        <section className="page-content-section">
          <h5>{title}</h5>

          {classHierachyOrder.map((classId) => (
            <div key={classId}>
              <h6>
                {parentsById[classId].Name}{" "}
                <Link
                  href={`/management-packs/${parentsById[classId].ManagementPackID}/classes/${classId}`}
                >
                  <a target="_blank">
                    <ExternalLinkIcon />
                  </a>
                </Link>
              </h6>

              {propsByClass[classId] ? (
                <>
                <Table responsive hover size="sm">
                  <thead>
                    <tr>
                      <th className="table-index-col">#</th>
                      <th className="table-prop-col">Name</th>
                      <th>Type</th>
                      <th className="center">Max Length</th>
                      <th>ID</th>
                      <th>Ref</th>
                    </tr>
                  </thead>
                  <tbody>
                    {propsByClass[classId]
                      .sort(OrderBy.localeCompare("Name"))
                      .map((m) => (
                        <tr key={m.ID}>
                          <td>{globalIndex++}</td>
                          <td className="table-prop-col">{m.Name}</td>
                          <td>
                            {m.EnumerationTypeID ? (
                              <Link
                                href={`/management-packs/${parentsById[classId].ManagementPackID}/enumerations/${m.EnumerationTypeID}`}
                              >
                                <a
                                  target="_blank"
                                  title="Regarder les éléments"
                                >
                                  enum <ExternalLinkIcon />
                                </a>
                              </Link>
                            ) : (
                              <span>{m.Type}</span>
                            )}
                          </td>
                          <td className="center">
                            { ['string', 'richtext'].includes(m.Type) ? m.MaxLength : "-"}
                          </td>
                          <td className="table-copy-col">
                            <CopyButton text={m.ID} />
                          </td>
                          <td className="table-copy-col">
                            <CopyButton text={m.XmlReferenceSample} />
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </Table>


</>
              ) : (
                <p><em>Aucune propriété</em></p>
              )}
            </div>
          ))}
        </section>



      )}
    </>
  );
}

import {
  addEntityToPersonalBookmark,
  checkEntityIsBookmarked,
  removeEntityFromPersonalBookmark,
} from "@/lib/entities-bookmarks";
import { useEffect, useState } from "react";

export type BookmarkButtonProps = {
  entityId: string;
  url: string;
  type: string;
  name: string;
};

export function BookmarkButton(props: BookmarkButtonProps) {
  const [active, setActive] = useState(false);

  useEffect(() => {
    setActive(checkEntityIsBookmarked(props.entityId));
  }, [props.entityId]);

  const toggleBookmark = () => {
    if (!active) {
      addEntityToPersonalBookmark(props.entityId, {
        id: props.entityId,
        url: props.url,
        type: props.type,
        name: props.name,
      });
    } else {
      removeEntityFromPersonalBookmark(props.entityId);
    }

    setActive(!active);
  };

  return (
    <span
      className="bookmark-icon"
      onClick={() => toggleBookmark()}
      title={active ? "Supprimer bookmark" : "Ajouter bookmark"}
    >
      <BookmarkIcon active={active} />
    </span>
  );
}

function BookmarkIcon(props: { active: boolean }) {
  return (
    <span>
      <img
        src={props.active ? "/bookmark_on.svg" : "/bookmark_off.svg"}
        width="32"
        height="32"
      />
    </span>
  );
}

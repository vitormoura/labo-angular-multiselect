import { IDetailedClass, ITypeProjection } from "@/lib/static-data-models";
import { type } from "os";
import { CopyButton } from "./copy-to-clipboard";

export type CriteriaQuerySampleForClassesProps = {
  classe: IDetailedClass;
};

export type CriteriaQuerySampleForTypeProjProps = {
  typeProj: ITypeProjection;
};

export function CriteriaQuerySampleForClasses({
  classe,
}: CriteriaQuerySampleForClassesProps) {
  const sampleProp = classe.Properties.find((p) => p.ClassID === classe.ID);
  const otherExpressions = sampleProp
    ? `<!-- Ou : Filtre par une propriété quelconque (Vous pouvez en combiner plus entourant les balises <Expression /> par <And /> ou <Or /> ) -->
  <Expression>                                            
      <SimpleExpression>
          <ValueExpressionLeft>
              <!-- Remplacez par la propriété souhaitée (Copiez l'extrait à partir du lien à côté de chaque propriété) -->
              <Property>${sampleProp.XmlReferenceSample}</Property>
          </ValueExpressionLeft>
          <Operator>Equal</Operator>
          <ValueExpressionRight>
              <Value>[VALEUR]</Value>
          </ValueExpressionRight>
      </SimpleExpression>
  </Expression>`
    : "";

  const xml = `<Criteria xmlns="http://Microsoft.EnterpriseManagement.Core.Criteria/">
    ${classe.MpXmlReferenceSample}
    
    <!-- Filtre par identifiant unique -->
    <Expression>                                            
        <SimpleExpression>
            <ValueExpressionLeft>
                <GenericProperty>FullName</GenericProperty>
            </ValueExpressionLeft>
            <Operator>Equal</Operator>
            <ValueExpressionRight>
                <Value>${classe.Name}:[VALEUR_ID]</Value>
            </ValueExpressionRight>
        </SimpleExpression>
    </Expression>
    ${otherExpressions}
</Criteria>`;

  return <CriteriaQuerySample xml={xml} />;
}

export function CriteriaQuerySampleForTypeProjection({
  typeProj,
}: CriteriaQuerySampleForTypeProjProps) {
  const sampleProp = typeProj.TargetType.Properties.find(
    (p) => p.ClassID === typeProj.TargetType.ID || true
  );

  const otherExpressions =
    typeProj.Components.length > 0
      ? ` <Expression>      
            <!-- Ex. Filtre par quelque propriété de la relation '${typeProj.Components[0].Name}' -->
            <SimpleExpression>
                <ValueExpressionLeft>
                    <Property>${typeProj.Components[0].XmlReferenceSample}</Property>
                </ValueExpressionLeft>
                <Operator>Equal</Operator>
                <ValueExpressionRight>
                    <Value>[VALEUR]</Value>
                </ValueExpressionRight>
            </SimpleExpression>
        </Expression>`
      : "";

  const xml = `<Criteria xmlns=""http://Microsoft.EnterpriseManagement.Core.Criteria/"">
    <!-- Ajoutez des REFS, selon les propriétés utilisées (Copiez l'extrait à partir du lien à côté de chaque composant/propriété) -->
    <!-- <Reference Id='MyManagementPackName' Version='0.0.0.0' PublicKeyToken='abcdefg' Alias='MP000XX' /> -->
    <!-- <Reference Id='MyManagementPackName' Version='0.0.0.0' PublicKeyToken='abcdefg' Alias='MP000XX' /> -->
    <Expression>
        <And>
            <Expression>
                <SimpleExpression>
                    <ValueExpressionLeft>
                        <!-- Remplacez par la propriété souhaitée du type cible -->
                        <Property>${sampleProp.XmlReferenceSample}</Property>
                    </ValueExpressionLeft>
                    <Operator>Equal</Operator>
                    <ValueExpressionRight>
                        <Value>[VALEUR]</Value>
                    </ValueExpressionRight>
                </SimpleExpression>
            </Expression>
            ${otherExpressions}
        </And>
    </Expression>
</Criteria>`;

  return <CriteriaQuerySample xml={xml} />;
}

function CriteriaQuerySample(props: { xml: string }) {
  return (
    <section className="page-content-section">
      <h5>
        Échantillon Criteria Query <CopyButton text={props.xml} />
      </h5>

      <pre className="cnt-xml-code" >{props.xml}</pre>

      <div>
        <strong>Remarque</strong>
        <br />
        <small>
          * Des propriétés de classes abstraites ne peuvent pas être utilisées
          en tant que filtres Criteria Xml
        </small>
      </div>
    </section>
  );
}

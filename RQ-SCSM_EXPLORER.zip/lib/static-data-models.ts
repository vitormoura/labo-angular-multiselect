export type GenericPageProps = {
  id: string;
  mp_id: string;
  object_name: string;
  object_type:string;
};

export interface IManagementPack {
  ID: string;
  Name: string;
  DisplayName: string;
  FriendlyName: string;
  KeyToken: string;
  Version: string;
  Alias: string;
  XmlReferenceSample: string;
  QttTypes: number;
}

export interface ISearchIndexEntry {
  ID: string;
  Position: number;
  ManagementPackID: string;
  Type: string;
  Name: string;
  DisplayName: string;
  SearchText: string;
}

export interface IManagementPackObjectType {
  ID: string;
  ManagementPackID: string;
  ParentId: string | null;
  Name: string;
}

export interface IDetailedManagementPack extends IManagementPack {
  Objects: {
    Classes: IManagementPackObjectType[];
    Enumerations: IManagementPackObjectType[];
    TypeProjections: IManagementPackObjectType[];
  };
}

export interface IClassProperty {
  ID: string;
  Name: string;
  Type: string;
  EnumerationTypeID: string;
  MinValue: number;
  MaxValue: number;
  Required: number;
  ClassID: string;
  DisplayName: string;
  IsKey: number;
  MaxLength: number;
  MinLength: number;
  Description: string;
  IsCaseSensitive: number;
  XmlReferenceSample: string;
}

export interface IBaseClass {
  ID: string;
  Name: string;
  DisplayName: string;
  Description: string;
  ManagementPackID: string;
  ManagementPackName: string;
  IsAbstract: number;
  ParentID: string;
  MpXmlReferenceSample: string;
}

export interface IDetailedClass extends IBaseClass {
  ParentTypes: IBaseClass[];
  DerivedTypes: IBaseClass[];
  Properties: IClassProperty[];
}

export interface IEnumerationItem {
  ID: string;
  Name: string;
  DisplayName: string;
  Description: string;
  Level: number;
  ParentID: string;
}

export interface ITypeProjectionComponent {
  ID: number;
  Name: string;
  Description: string;
  TargetTypeID: string;
  TargetTypeName: string;
  TargetTypeManagementPackID: string;
  TargetTypeManagementPackXmlReferenceSample: string;
  TypeProjectionID: string;
  ConstraintTypeID: string;
  MaxCardinality: number;
  MinCardinality: number;
  XmlReferenceSample: string;
}

export interface ITypeProjection {
  ID: string;
  Name: string;
  DisplayName: string;
  ManagementPackID: string;
  ManagementPackName: string;
  TargetTypeID: string;

  TargetType: IDetailedClass;
  Components: ITypeProjectionComponent[];
}

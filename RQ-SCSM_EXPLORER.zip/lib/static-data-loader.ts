import lineByLine from "n-readlines";
import path from "path";
import fs from "fs";
import {
  IDetailedClass,
  IDetailedManagementPack,
  IEnumerationItem,
  IManagementPack,
  IManagementPackObjectType,
  ISearchIndexEntry,
  ITypeProjection,
} from "./static-data-models";
import sqlite3 from "sqlite3";

const DB_PATH = "./data/scsm-metadonnees.sqlite3";
const QUERY_MP_TOUS =
  "SELECT MP.*, v.QTT_TYPES as QttTypes FROM VIW_SCSM_MP_WITH_TYPES V INNER JOIN TAB_MANAGEMENTPACK MP ON MP.ID = v.ID ";

export async function recupererElementsEnumParId(
  id: string
): Promise<IEnumerationItem[]> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        let items = [] as IEnumerationItem[];

        db.each(
          `WITH RECURSIVE
          child_enumerations(ID, Name, DisplayName, Description, ParentID, Level) AS (
            SELECT E.ID, E.Name, E.DisplayName, E.Description, E.ParentID, 0 FROM TAB_ENUMERATION E WHERE E.ID = '${id}'
            UNION
            SELECT E.ID, E.Name, E.DisplayName, E.Description, E.ParentID, Level + 1 	FROM TAB_ENUMERATION E, child_enumerations WHERE E.ParentID = child_enumerations.id ORDER BY E.DisplayName
          )
          SELECT ID, Name, DisplayName, Description, ParentID, Level FROM child_enumerations
          `,
          (err, row) => {
            if (err) reject(err);
            items.push(row);
          },
          () => {
            resolve(items);
            db.close();
          }
        );
      });
    });
  });
}

export async function recupererClassDetaileeParId(
  id: string
): Promise<IDetailedClass> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        let cl: IDetailedClass = null;

        db.each(
          `SELECT C.*, MP.Name AS ManagementPackName, MP.XmlReferenceSample as MpXmlReferenceSample FROM TAB_MCLASS C INNER JOIN TAB_MANAGEMENTPACK MP ON MP.ID = C.ManagementPackID WHERE C.ID = '${id}'`,
          (err, row) => {
            if (err) reject(err);
            cl = {
              ...row,
              Properties: [],
              ParentTypes: [],
              DerivedTypes: [],
            };
          },

          () => {
            db.each(
              `WITH RECURSIVE
                  parent_classes(ID, Ord) AS (
                    VALUES('${id}', 0)
                    UNION
                    SELECT C.ParentID, Ord + 1 FROM TAB_MCLASS C, parent_classes WHERE C.ID = parent_classes.ID
                  )
                SELECT * FROM TAB_MCLASS C INNER JOIN parent_classes P ON p.ID = c.ID ORDER BY P.Ord DESC`,
              (err, row) => {
                if (err) return reject(err);

                if (row.ID !== id) {
                  cl.ParentTypes.push(row);
                }
              },
              () => {
                const parentsIds = cl.ParentTypes.map((p) => `'${p.ID}'`);
                parentsIds.push(`'${cl.ID}'`);

                db.each(
                  `SELECT * FROM TAB_MCLASS_PROP WHERE ClassId IN (${parentsIds.join(
                    ","
                  )}) ORDER BY ClassId`,
                  (err, row) => {
                    if (err) return reject(err);
                    cl.Properties.push(row);
                  },

                  () => {
                    db.each(
                      `WITH RECURSIVE
                        derived_classes(ID) AS (
                          VALUES('${id}')
                          UNION
                          SELECT C.ID FROM TAB_MCLASS C, derived_classes WHERE C.ParentID = derived_classes.ID
                        )
                      SELECT * FROM TAB_MCLASS C where C.ID in derived_classes`,
                      (err, row) => {
                        if (err) return reject(err);

                        if (row.ID !== id) {
                          cl.DerivedTypes.push(row);
                        }
                      },
                      () => {
                        resolve(cl);
                        db.close();
                      }
                    );
                  }
                );
              }
            );
          }
        );
      });
    });
  });
}

export async function recupererTypeProjectionParId(
  id: string
): Promise<ITypeProjection> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        let tp: ITypeProjection = null;

        db.each(
          `SELECT TP.*, MP.Name AS ManagementPackName FROM TAB_TYPEPROJECTION TP INNER JOIN TAB_MANAGEMENTPACK MP ON MP.ID = TP.ManagementPackID WHERE TP.ID = '${id}'`,
          (err, row) => {
            if (err) return reject(err);
            tp = {
              ...row,
              Components: [],
            };
          },

          () => {
            db.each(
              `SELECT TPC.*, C.Name as TargetTypeName, C.ManagementPackID AS TargetTypeManagementPackID, MP.XmlReferenceSample as TargetTypeManagementPackXmlReferenceSample FROM TAB_TYPEPROJECTION_COMP TPC INNER JOIN TAB_MCLASS C ON C.ID = TPC.TargetTypeId INNER JOIN TAB_MANAGEMENTPACK MP ON MP.ID = C.ManagementPackID WHERE TypeProjectionID = '${id}'`,
              (err, row) => {
                if (err) return reject(err);

                tp.Components.push(row);
              },
              () => {
                db.close();

                recupererClassDetaileeParId(tp.TargetTypeID).then((cl) => {
                  tp.TargetType = cl;

                  resolve(tp);
                });
              }
            );
          }
        );
      });
    });
  });
}

export function recupererInfoManagementPackParId(
  id: string
): Promise<IDetailedManagementPack> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) {
        return reject(err);
      }

      db.serialize(() => {
        let mp: IDetailedManagementPack = null;

        db.each(
          `${QUERY_MP_TOUS} WHERE MP.ID = '${id}'`,
          (err, row) => {
            if (err) return reject(err);
            mp = {
              ...row,
              Objects: {
                Classes: [],
                Enumerations: [],
                TypeProjections: [],
              },
            };
          },
          () => {
            db.each(
              `SELECT * FROM VIW_SCSM_TYPES WHERE MP_ID = '${mp.ID}'`,
              (err, row: { ID: string; TYPE: string; NAME: string }) => {
                if (err) return reject(err);

                switch (row.TYPE) {
                  case "ENUM":
                    mp.Objects.Enumerations.push({
                      ID: row.ID,
                      Name: row.NAME,
                      ManagementPackID: mp.ID,
                      ParentId: null,
                    });
                    break;
                  case "CLASS":
                    mp.Objects.Classes.push({
                      ID: row.ID,
                      Name: row.NAME,
                      ManagementPackID: mp.ID,
                      ParentId: null,
                    });
                    break;
                  case "TYPE_PROJ":
                    mp.Objects.TypeProjections.push({
                      ID: row.ID,
                      Name: row.NAME,
                      ManagementPackID: mp.ID,
                      ParentId: null,
                    });
                    break;
                }
              },
              () => {
                resolve(mp);
                db.close();
              }
            );
          }
        );
      });
    });
  });
}

export function recupererListeTypesObject(
  type: string
): Promise<IManagementPackObjectType[]> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        let items = [] as IManagementPackObjectType[];

        db.each(
          `SELECT ID, MP_ID as ManagementPackID, NAME as Name FROM VIW_SCSM_TYPES WHERE TYPE ='${type}'`,
          (err, row) => {
            if (err) reject(err);
            items.push(row);
          },
          () => {
            resolve(items);
            db.close();
          }
        );
      });
    });
  });
}

export function recupererManagementPacks(): Promise<IManagementPack[]> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) {
        return reject(err);
      }

      db.serialize(() => {
        let mps = [] as IManagementPack[];

        db.each(
          QUERY_MP_TOUS,
          (err, row) => {
            if (err) {
              console.error(err);
              return;
            }

            mps.push(row);
          },
          () => {
            resolve(mps);
            db.close();
          }
        );
      });
    });
  });
}

export function recupererListeEntreesIndexRecherche() {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) {
        return reject(err);
      }

      db.serialize(() => {
        let liste = [] as ISearchIndexEntry[];
        let pos = 0;

        db.each(
          "SELECT * FROM VIW_INDEX_ELEMENTS_SCSM",
          (err, row) => {
            if (err) return reject(err);

            liste.push({
              ...row,
              Position: pos++,
            });
          },
          (err) => {
            resolve(liste);
            db.close();
          }
        );
      });
    });
  });
}

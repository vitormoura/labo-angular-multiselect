export function getSimplifiedName(name: string, separator = ".") {
  if (!name || name.length < 2) {
    return name;
  }

  const posLastSeparator = name.lastIndexOf(separator);

  if (posLastSeparator < 0) {
    return name;
  }

  return name.substr(posLastSeparator + 1);
}

export const OrderBy = {
  localeCompare: (prop: string) => {
    return (a: any, b: any) => {
      if (prop) {
        return a[prop].localeCompare(b[prop]);
      } else {
        return a.localeCompare(b);
      }
    };
  },
};

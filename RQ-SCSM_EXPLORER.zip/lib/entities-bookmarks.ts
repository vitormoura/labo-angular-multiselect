import Lockr from "lockr";

const KEY_ENTITY_LIST = "entities";

Lockr.prefix = "scsmexpv1_";

export interface IEntityBookmarkDetails {
  id: string;
  url: string;
  type: string;
  name: string;
}

export function addEntityToPersonalBookmark(
  id: string,
  details: IEntityBookmarkDetails
) {
  Lockr.sadd(KEY_ENTITY_LIST, id);
  Lockr.set(id, details);
}

export function removeEntityFromPersonalBookmark(id: string) {
  Lockr.srem(KEY_ENTITY_LIST, id);
  Lockr.rm(id);
}

export function checkEntityIsBookmarked(id: string) {
  return Lockr.sismember(KEY_ENTITY_LIST, id);
}

export function getPersonnalBookmarkCollection(): Promise<
  IEntityBookmarkDetails[]
> {
  return new Promise((resolve, reject) => {
    const ids = Lockr.smembers(KEY_ENTITY_LIST) as string[];
    const result = [] as IEntityBookmarkDetails[];

    ids.forEach((id) => {
      const detail = Lockr.get(id) as IEntityBookmarkDetails;
      result.push(detail);
    });

    resolve(result);
  });
}

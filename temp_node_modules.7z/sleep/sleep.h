#ifndef SLEEP_H
#define SLEEP_H

#include <nan.h>

void node_usleep(uint32_t usec);

#endif // SLEEP_H

import {
  IDetailedClass,
  ITypeProjection,
  ITypeProjectionComponent,
} from "@/lib/static-data-models";

import { CopyButton } from "./copy-to-clipboard";

export type CSharpCodeSampleForClassesProps = {
  classe: IDetailedClass;
};

export type CSharpCodeSampleForTypeProjProps = {
  typeProj: ITypeProjection;
};

export function CSharpCodeSampleForClasses({
  classe,
}: CSharpCodeSampleForClassesProps) {
  return <CSharpCodeSample code={createCSharpCode(classe, [])} />;
}

export function CSharpCodeSampleForTypeProjection({
  typeProj,
}: CSharpCodeSampleForTypeProjProps) {
  return (
    <CSharpCodeSample
      code={createCSharpCode(typeProj.TargetType, typeProj.Components)}
    />
  );
}

function mapTypes(type: string): string {
  switch (type) {
    case "string":
    case "richtext":
      return "string";
    case "enum":
      return "ObjetGeneriqueSimple<Guid>";
    case "bool":
      return "bool?";
    case "datetime":
      return "DateTime?";
    case "decimal":
      return "decimal?";
    case "double":
      return "double?";
    case "int":
      return "int?";
    default:
      return "object";
  }
}

function firstLetterLowerCase(value: string) {
  return value[0].toLocaleLowerCase() + value.substr(1);
}

function createCSharpCode(
  classe: IDetailedClass,
  relationships: ITypeProjectionComponent[]
) {
  const lines = [];
  const csharpClassName = classe.Name.replaceAll(".", "_");

  lines.push("using System;");
  lines.push("using OW99.ITSM.SCSMServices.Domaine.Recherche;");
  lines.push("using Newtonsoft.Json.Linq;");
  lines.push("using System.Collections.Generic;");
  lines.push("");

  lines.push("namespace MyApp.Types {");
  lines.push("");

  lines.push(`    /// <summary>`);
  lines.push(`    /// Classe SCSM ${classe.Name}`);
  lines.push(`    /// </summary>`);

  lines.push(
    `    public ${
      classe.IsAbstract ? "abstract" : ""
    } partial class ${csharpClassName} {`
  );
  lines.push("");

  lines.push("        private readonly ObjetGeneriqueComplet _source;");
  lines.push("");

  lines.push("        #region Properties");
  lines.push("");

  classe.Properties.forEach((p) => {
    const propName = firstLetterLowerCase(p.Name);

    lines.push(`        /// <summary>`);
    lines.push(
      `        /// ${p.Description ?? p.DisplayName} ${p.IsKey ? "(key)" : ""}`
    );
    lines.push(`        /// </summary>`);

    if (p.Type !== "enum") {
      lines.push(
        `        public ${mapTypes(p.Type)} ${
          p.Name
        } { get { return Get<${mapTypes(p.Type)}>("${propName}"); } }`
      );
    } else {
      lines.push(
        `        public ${mapTypes(p.Type)} ${
          p.Name
        } { get { return GetEnum("${propName}"); } }`
      );
    }

    lines.push("");
  });

  lines.push("        #endregion");
  lines.push("");

  if (relationships && relationships.length > 0) {
    lines.push("        #region Relationships");
    lines.push("");

    relationships.forEach((rel) => {
      const targetClassName = rel.TargetTypeName.replaceAll(".", "_");
      const relPropName = firstLetterLowerCase(rel.Name);

      lines.push(`        /// <summary>`);
      lines.push(`        /// Relation ${rel.Name} (Type ${targetClassName})`);
      lines.push(`        /// </summary>`);
      lines.push(
        `        public List<ObjetGeneriqueComplet> ${rel.Name} { get { return _source.Relationships != null && _source.Relationships.ContainsKey("${relPropName}") ? _source.Relationships["${relPropName}"] : null; } }`
      );
      lines.push("");
    });

    lines.push("        #endregion");
    lines.push("");
  }

  lines.push("");

  lines.push(`        /// <summary>`);
  lines.push(`        /// Crée une nouvelle instance de ${csharpClassName}`);
  lines.push(`        /// </summary>`);

  lines.push(`        public ${csharpClassName}(ObjetGeneriqueComplet source)`);
  lines.push(`        {`);
  lines.push(`            _source = source;`);
  lines.push(`        }`);

  lines.push(``);
  lines.push(`        protected T Get<T>(string key)`);
  lines.push(`        {`);
  lines.push(`            if (!_source.Properties.ContainsKey(key) || !(_source.Properties[key] is T))`);
  lines.push(`            {`);
  lines.push(`                return default(T);`);
  lines.push(`            }`);
  lines.push(``);
  lines.push(`            return (T)_source.Properties[key];`);
  lines.push(`        }`);

  lines.push(``);

  lines.push(`        protected ${mapTypes("enum")} GetEnum(string key)`);
  lines.push(`        {`);
  lines.push(`            var value = Get<${mapTypes("enum")}>(key);`);
  lines.push(`            `);

  lines.push(`            if(value == null)`);
  lines.push(`            {`);
  lines.push(`                var valueAsJObject = Get<JObject>(key);`);
  lines.push(``);
  lines.push(`                if(valueAsJObject != null) { `);
  lines.push(
    `                    return (${mapTypes(
      "enum"
    )}) valueAsJObject.ToObject(typeof(${mapTypes("enum")}));`
  );
  lines.push(`                }`);
  lines.push(`            }`);
  lines.push(``);
  lines.push(`            return value;`);
  lines.push(`        }`);
  lines.push(``);

  lines.push("    }");
  lines.push("}");

  return lines.join("\n");
}

function CSharpCodeSample(props: { code: string }) {
  return (
    <section className="page-content-section">
      <h5>
        Échantillon Classe C# <CopyButton text={props.code} />
      </h5>

      <pre>
        <code className="language-csharp">{props.code}</code>
      </pre>
    </section>
  );
}

export type CardinalityInfoProps = {
  min: number;
  max: number;
};

export function CardinalityInfo({ min, max }: CardinalityInfoProps) {
  return (
    <span>
      {min}..{max > 100 ? "*" : max}
    </span>
  );
}

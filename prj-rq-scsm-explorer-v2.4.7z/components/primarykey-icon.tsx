import React from "react";

export function PrimaryKeyIcon() {
    return (
      <span style={{color:'#FF0', margin:"0 5px"}}>
        <img src={"/door-key.svg"} width="12" height="12" />
      </span>
    );
  }
  
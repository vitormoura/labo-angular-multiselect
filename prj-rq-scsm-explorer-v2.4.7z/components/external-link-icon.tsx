import React from "react";

export function ExternalLinkIcon() {
  return (
    <span style={{color:'#FF0'}}>
      <img src={"/external-link.svg"} width="12" height="12" />
    </span>
  );
}

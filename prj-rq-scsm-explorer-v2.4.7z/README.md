# SCSM Entity Explorer

## Getting Started

**Attention**

Cette application s'utilise des métadonnées fournies par SCSM pour générer ses pages. 

Alors, avant commencer, il faut copier la version courante du fichier scsm-metadonees.sqlite3 (générée par l'outil MetadonneesSCSM) dans le répertoire /data. Ce fichier doit être mis à jour à chaque changement majeur des métadonnées de SCSM. 

Ensuite, lancez le serveur de développement: 
 

```bash
npm run dev
# or
yarn dev
```

Ouvrez [http://localhost:3000](http://localhost:3000) dans votre navigateur pour regarder les résultats.

## Site statique 

Pour générer une nouvelle version du site `rq-scsm-explorer`, lancez:

```bash
npm run build
```

Les fichiers du site seront placés dans le répertoire `out` du projet. Vous pouvez le tester en utilisant un serveur web simple, tel comme `http-server` ou utilisant l'extension `Live Server` de Visual Studio Code. 

## Librairies utilisées

- https://nextjs.org/
- https://react-bootstrap.github.io/
- https://lodash.com/
- https://lunrjs.com/
- https://github.com/tsironis/lockr
- https://www.npmjs.com/package/sqlite3

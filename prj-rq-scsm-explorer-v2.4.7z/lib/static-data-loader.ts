import {
  IBaseClass,
  IDetailedClass,
  IDetailedManagementPack,
  IEnumerationItem,
  IManagementPack,
  IManagementPackObjectType,
  IObjectTemplate,
  ISearchIndexEntry,
  ITypeProjection,
  ObjectTemplatePropertyType,
} from "./static-data-models";
import sqlite3 from "sqlite3";
import orderBy from 'lodash/orderBy'

const DB_PATH = "./data/scsm-metadonnees.sqlite3";

export async function recupererElementsEnumParId(
  id: string
): Promise<IEnumerationItem[]> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        let items = [] as IEnumerationItem[];

        db.each(
          `WITH RECURSIVE
          child_enumerations(ID, Name, DisplayName, Description, ParentID, Ordinal, Level) AS (
            SELECT E.ID, E.Name, E.DisplayName, E.Description, E.ParentID, E.Ordinal, 0 FROM TAB_ENUMERATION E WHERE E.ID = '${id}'
            UNION
            SELECT E.ID, E.Name, E.DisplayName, E.Description, E.ParentID, E.Ordinal, Level + 1	FROM TAB_ENUMERATION E, child_enumerations CE WHERE E.ParentID = CE.id ORDER BY E.ParentID
          )
          SELECT ID, Name, DisplayName, Description, ParentID, Ordinal, Level FROM child_enumerations ORDER BY ParentID
          `,
          (err, row) => {
            if (err) reject(err);
            items.push(row);
          },
          () => {
            db.close();

            const orderedResult= [];
            const fillChildren = (item: IEnumerationItem) => {
              if(!item) { 
                return
              }

              orderedResult.push(item);

              const children = items.filter(cc => cc.ParentID === item.ID)

              if(children.length > 0) {
                orderBy(children, ['Ordinal']).forEach(c => {
                  fillChildren(c)
                })
              }
            }
            
            fillChildren(items[0]);

            resolve(orderedResult);
          }
        );
      });
    });
  });
}

export async function recupererClassDetaileeParId(
  id: string
): Promise<IDetailedClass> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        let cl: IDetailedClass = null;

        db.each(
          `SELECT C.*, MP.Name AS ManagementPackName, MP.XmlReferenceSample as MpXmlReferenceSample FROM TAB_MCLASS C INNER JOIN TAB_MANAGEMENTPACK MP ON MP.ID = C.ManagementPackID WHERE C.ID = '${id}'`,
          (err, row) => {
            if (err) reject(err);
            cl = {
              ...row,
              Properties: [],
              ParentTypes: [],
              DerivedTypes: [],
            };
          },

          () => {
            db.each(
              `WITH RECURSIVE
                  parent_classes(ID, Ord) AS (
                    VALUES('${id}', 0)
                    UNION
                    SELECT C.ParentID, Ord + 1 FROM TAB_MCLASS C, parent_classes WHERE C.ID = parent_classes.ID
                  )
                  SELECT c.*, mp.XmlReferenceSample AS MpXmlReferenceSample FROM TAB_MCLASS c INNER JOIN parent_classes P ON p.ID = c.ID INNER JOIN TAB_MANAGEMENTPACK mp ON c.ManagementPackID = mp.ID ORDER BY P.Ord DESC`,
              (err, row) => {
                if (err) return reject(err);

                if (row.ID !== id) {
                  cl.ParentTypes.push(row);
                }
              },
              () => {
                const parentsIds = cl.ParentTypes.map((p) => `'${p.ID}'`);
                parentsIds.push(`'${cl.ID}'`);

                db.each(
                  `SELECT * FROM TAB_MCLASS_PROP WHERE ClassId IN (${parentsIds.join(
                    ","
                  )}) ORDER BY ClassId`,
                  (err, row) => {
                    if (err) return reject(err);
                    cl.Properties.push(row);
                  },

                  () => {
                    db.each(
                      `WITH RECURSIVE
                        derived_classes(ID) AS (
                          VALUES('${id}')
                          UNION
                          SELECT C.ID FROM TAB_MCLASS C, derived_classes WHERE C.ParentID = derived_classes.ID
                        )
                      SELECT * FROM TAB_MCLASS C where C.ID in derived_classes`,
                      (err, row) => {
                        if (err) return reject(err);

                        if (row.ID !== id) {
                          cl.DerivedTypes.push(row);
                        }
                      },
                      () => {
                        resolve(cl);
                        db.close();
                      }
                    );
                  }
                );
              }
            );
          }
        );
      });
    });
  });
}

export async function recupererTypeProjectionsParTypeCible(
  idCible: string
): Promise<IBaseClass[]> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        let items = [] as IBaseClass[];

        db.each(
          `SELECT
              tt.ID,
              tt.Name,
              tt.DisplayName,
              '' as Description,
              tt.ManagementPackID,
              tm.Name as ManagementPackName,
              tm2.IsAbstract,
              tm2.ParentID,
              tm.XmlReferenceSample as MpXmlReferenceSample
            FROM
              TAB_TYPEPROJECTION tt
            INNER JOIN TAB_MANAGEMENTPACK tm ON
              tm.ID = tt.ManagementPackID
            INNER JOIN TAB_MCLASS tm2 ON
              tm2.ID = tt.TargetTypeID
            WHERE
              TargetTypeID = '${idCible}'`,
          (err, row) => {
            if (err) reject(err);
            items.push(row);
          },
          () => {
            resolve(items);
            db.close();
          }
        );
      });
    });
  });
}

export async function recupererTypeProjectionParId(
  id: string
): Promise<ITypeProjection> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        let tp: ITypeProjection = null;

        db.each(
          `SELECT TP.*, MP.Name AS ManagementPackName FROM TAB_TYPEPROJECTION TP INNER JOIN TAB_MANAGEMENTPACK MP ON MP.ID = TP.ManagementPackID WHERE TP.ID = '${id}'`,
          (err, row) => {
            if (err) return reject(err);
            tp = {
              ...row,
              Components: [],
              Templates: [],
            };
          },

          () => {
            db.each(
              `SELECT TPC.*, C.Name as TargetTypeName, C.ManagementPackID AS TargetTypeManagementPackID, MP.XmlReferenceSample as TargetTypeManagementPackXmlReferenceSample FROM TAB_TYPEPROJECTION_COMP TPC INNER JOIN TAB_MCLASS C ON C.ID = TPC.TargetTypeId INNER JOIN TAB_MANAGEMENTPACK MP ON MP.ID = C.ManagementPackID WHERE TypeProjectionID = '${id}'`,
              (err, row) => {
                if (err) return reject(err);

                tp.Components.push(row);
              },
              () => {
                recupererClassDetaileeParId(tp.TargetTypeID).then((cl) => {
                  tp.TargetType = cl;

                  db.each(
                    `SELECT * FROM TAB_TEMPLATE WHERE TypeProjectionID = '${id}'`,
                    (err, row) => {
                      if (err) return reject(err);

                      tp.Templates.push(row);
                    },
                    () => {
                      resolve(tp);
                      db.close();
                    }
                  );
                });
              }
            );
          }
        );
      });
    });
  });
}

export async function recupererGabaritObjetParId(
  id: string
): Promise<IObjectTemplate> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        let tp: IObjectTemplate = null;

        db.each(
          `
          SELECT 
            TP.*, 
            MP.Name as ManagementPackName,
            TPROJ.ID as TPROJ_ID,
            TPROJ.DisplayName as TPROJ_DisplayName,
            TPROJ.Name as TPROJ_Name,
            TPROJ.ManagementPackID as TPROJ_ManagementPackID
          FROM 
            TAB_TEMPLATE TP 
            INNER JOIN TAB_MANAGEMENTPACK MP ON MP.ID = TP.ManagementPackID 
            LEFT JOIN TAB_TYPEPROJECTION TPROJ ON TPROJ.ID = TP.TypeProjectionID
          WHERE 
            TP.ID = '${id}'`,
          (err, row) => {
            if (err) return reject(err);

            if (row.TPROJ_ID) {
              row.TypeProjection = {};

              Object.keys(row)
                .filter((k) => k.startsWith("TPROJ_"))
                .forEach((k) => {
                  row.TypeProjection[k.replace("TPROJ_", "")] = row[k];
                  delete row[k];
                });
            }

            tp = {
              ...row,
              Properties: [],
            };
          },

          () => {
            db.each(
              `SELECT 
              TPP.*, 
              EN.Name as Enum_Name, 
              EN.ID as Enum_ID, 
              EN.DisplayName as ENUM_DisplayName, 
              EN.ManagementPackID as ENUM_ManagementPackID
            FROM 
              TAB_TEMPLATE_PROPS TPP 
              LEFT JOIN TAB_ENUMERATION EN ON ((EN.ID = TPP.Value AND TPP.Type = 3) OR (EN.Name = TPP.Value AND TPP.Type = 2))
            WHERE 
              TPP.TemplateID = '${id}'`,
              (err, row) => {
                if (err) return reject(err);

                let typeProp = "General" as ObjectTemplatePropertyType;

                switch (row.Type) {
                  case 1:
                    typeProp = "General";
                    break;
                  case 2:
                    typeProp = "Enum-Name";
                    break;
                  case 3:
                    typeProp = "Enum-ID";
                    break;
                  case 4:
                    typeProp = "EmailTemplate";
                    break;
                  case 5:
                    typeProp = "Script";
                    break;
                }

                row.Type = typeProp;

                if (row.Enum_ID) {
                  row.EnumValue = {
                    Name: row.Enum_Name,
                    ID: row.Enum_ID,
                    DisplayName: row.ENUM_DisplayName,
                    ManagementPackID: row.ENUM_ManagementPackID,
                  };

                  delete row.Enum_Name;
                  delete row.Enum_ID;
                  delete row.ENUM_DisplayName;
                  delete row.ENUM_ManagementPackID;
                }

                tp.Properties.push(row);
              },
              () => {
                db.close();
                resolve(tp);
              }
            );
          }
        );
      });
    });
  });
}

export function recupererInfoManagementPackParId(
  id: string
): Promise<IDetailedManagementPack> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) {
        return reject(err);
      }

      db.serialize(() => {
        let mp: IDetailedManagementPack = null;

        db.each(
          `SELECT MP.*, v.QTT_TYPES as QttTypes FROM VIW_SCSM_MP_WITH_TYPES V INNER JOIN TAB_MANAGEMENTPACK MP ON MP.ID = v.ID  WHERE MP.ID = '${id}'`,
          (err, row) => {
            if (err) return reject(err);
            mp = {
              ...row,
              Objects: {
                Classes: [],
                Enumerations: [],
                TypeProjections: [],
                Templates: [],
              },
            };
          },
          () => {
            db.each(
              `SELECT * FROM VIW_SCSM_TYPES WHERE MP_ID = '${mp.ID}'`,
              (
                err,
                row: {
                  ID: string;
                  TYPE: string;
                  NAME: string;
                  DISPLAY_NAME: string;
                }
              ) => {
                if (err) return reject(err);

                switch (row.TYPE) {
                  case "ENUM":
                    mp.Objects.Enumerations.push({
                      ID: row.ID,
                      Name: row.NAME,
                      ManagementPackID: mp.ID,
                      ParentId: null,
                      DisplayName: row.DISPLAY_NAME,
                    });
                    break;
                  case "CLASS":
                    mp.Objects.Classes.push({
                      ID: row.ID,
                      Name: row.NAME,
                      ManagementPackID: mp.ID,
                      ParentId: null,
                      DisplayName: row.DISPLAY_NAME,
                    });
                    break;
                  case "TYPE_PROJ":
                    mp.Objects.TypeProjections.push({
                      ID: row.ID,
                      Name: row.NAME,
                      ManagementPackID: mp.ID,
                      ParentId: null,
                      DisplayName: row.DISPLAY_NAME,
                    });
                    break;
                  case "TEMPLATE":
                    mp.Objects.Templates.push({
                      ID: row.ID,
                      Name: row.NAME,
                      ManagementPackID: mp.ID,
                      ParentId: null,
                      DisplayName: row.DISPLAY_NAME,
                    });
                    break;
                }
              },
              () => {
                resolve(mp);
                db.close();
              }
            );
          }
        );
      });
    });
  });
}

export function recupererListeTypesObject(
  type: string
): Promise<IManagementPackObjectType[]> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) return reject(err);

      db.serialize(() => {
        let items = [] as IManagementPackObjectType[];

        db.each(
          `SELECT ID, MP_ID as ManagementPackID, NAME as Name FROM VIW_SCSM_TYPES WHERE TYPE ='${type}'`,
          (err, row) => {
            if (err) reject(err);
            items.push(row);
          },
          () => {
            resolve(items);
            db.close();
          }
        );
      });
    });
  });
}

export function recupererManagementPacks(): Promise<IManagementPack[]> {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) {
        return reject(err);
      }

      db.serialize(() => {
        let mps = [] as IManagementPack[];

        db.each(
          `SELECT MP.*, v.QTT_TYPES as QttTypes FROM VIW_SCSM_MP_WITH_TYPES V INNER JOIN TAB_MANAGEMENTPACK MP ON MP.ID = v.ID `,
          (err, row) => {
            if (err) {
              console.error(err);
              return;
            }

            mps.push(row);
          },
          () => {
            resolve(mps);
            db.close();
          }
        );
      });
    });
  });
}

export function recupererListeEntreesIndexRecherche() {
  return new Promise((resolve, reject) => {
    let db = new sqlite3.Database(DB_PATH, sqlite3.OPEN_READONLY, (err) => {
      if (err) {
        return reject(err);
      }

      db.serialize(() => {
        let liste = [] as ISearchIndexEntry[];
        let pos = 0;

        db.each(
          "SELECT * FROM VIW_INDEX_ELEMENTS_SCSM",
          (err, row) => {
            if (err) return reject(err);

            liste.push({
              ...row,
              Position: pos++,
            });
          },
          (err) => {
            resolve(liste);
            db.close();
          }
        );
      });
    });
  });
}

import { GetStaticPaths, GetStaticProps } from "next";
import {
  InputGroup,
  FormControl,
  Badge,
  Card,
  Container,
  ListGroup,
  Button,
  Row,
  Col,
} from "react-bootstrap";
import { recupererManagementPacks } from "../../lib/static-data-loader";
import { IManagementPack } from "../../lib/static-data-models";
import Link from "next/link";
import { OrderBy } from "@/lib/ui-utils";

type PageProps = {
  managementPacks: IManagementPack[];
};

export default function ManagementPackListPage({ managementPacks }: PageProps) {
  return (
    <Container>
      <h1 className="page-title">Management Packs</h1>

      <Card className="app-page-content-card">
        <Card.Body>
          <section className="page-content-section liste-elements">
            <ListGroup variant="flush">
              {managementPacks
                .sort(OrderBy.localeCompare("Name"))
                .map((mp, index) => (
                  <ListGroup.Item key={mp.ID}>
                    <Row>
                      <Col>
                        <strong>
                          <Link href={`/management-packs/${mp.ID}/info`}>
                            <a>
                              {index + 1}. {mp.Name}
                            </a>
                          </Link>
                        </strong>
                        <br />
                        <span>{mp.DisplayName}</span>
                      </Col>
                      <Col md={2}>{mp.Alias}</Col>
                      <Col md={1}>
                        <span>{mp.QttTypes} types</span>
                      </Col>
                    </Row>
                  </ListGroup.Item>
                ))}
            </ListGroup>
          </section>
        </Card.Body>
      </Card>
    </Container>
  );
}

/////////////////////////////////////

export const getStaticProps: GetStaticProps = async (context) => {
  const managementPacks = await recupererManagementPacks();

  return {
    props: {
      title: "Management Packs",
      managementPacks,
    } as PageProps,
  };
};

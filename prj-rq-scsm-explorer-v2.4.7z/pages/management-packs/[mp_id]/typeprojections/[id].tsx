import {
  recupererListeTypesObject,
  recupererTypeProjectionParId,
} from "@/lib/static-data-loader";
import { GenericPageProps, ITypeProjection } from "@/lib/static-data-models";
import { GetStaticPaths, GetStaticProps } from "next";
import { Card, Table } from "react-bootstrap";

import Link from "next/link";
import { CopyButton } from "@/components/copy-to-clipboard";
import { PropertyList } from "@/components/class-property-list";
import { ExternalLinkIcon } from "@/components/external-link-icon";
import { OrderBy } from "@/lib/ui-utils";
import { CardinalityInfo } from "@/components/cardinality-info";
import { CriteriaQuerySampleForTypeProjection } from "@/components/criteria-query-sample";
import { BookmarkButton } from "@/components/bookmark-button";
import { CSharpCodeSampleForTypeProjection } from "@/components/csharp-code-sample";

interface PageProps extends GenericPageProps {
  id: string;
  typeProjection: ITypeProjection;
}

export default function PageTypeProjectionDetails({
  typeProjection,
}: PageProps) {
  return (
    <>
      <h1 className="page-title">
        <strong>{typeProjection.Name}</strong>

        <BookmarkButton
          entityId={typeProjection.ID}
          url={`/management-packs/${typeProjection.ManagementPackID}/typeprojections/${typeProjection.ID}`}
          name={typeProjection.Name}
          type="Type Projections"
        />
      </h1>

      <Card className="app-page-content-card">
        <Card.Body>
          <section className="page-content-section">
            <h5>Informations générales</h5>

            <dl>
              <dt>
                Identifiant <CopyButton text={typeProjection.ID} />
              </dt>
              <dd>{typeProjection.ID}</dd>

              <dt>Nom</dt>
              <dd>{typeProjection.Name}</dd>

              <dt>Description</dt>
              <dd>{typeProjection.DisplayName || "-"}</dd>

              <dt>Management Pack</dt>
              <dd>
                <Link
                  href={`/management-packs/${typeProjection.ManagementPackID}/info`}
                >
                  <a target="_blank">
                    {typeProjection.ManagementPackName} <ExternalLinkIcon />
                  </a>
                </Link>
              </dd>

              <dt>Type cible</dt>
              <dd>
                <Link
                  href={`/management-packs/${typeProjection.TargetType.ManagementPackID}/classes/${typeProjection.TargetType.ID}`}
                >
                  <a target="_blank">
                    {typeProjection.TargetType.Name} <ExternalLinkIcon />
                  </a>
                </Link>
              </dd>
            </dl>
          </section>

          <PropertyList
            title="Propriétés Type Cible"
            classe={typeProjection.TargetType}
          />

          <section className="page-content-section">
            <h5>Composants da la Projection</h5>

            <Table responsive hover size="sm">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Nom</th>
                  <th>Type cible</th>
                  <th className="center">Cardinalité </th>
                  <th className="center">RMP</th>
                  <th className="center">RRE</th>
                </tr>
              </thead>
              <tbody>
                {typeProjection.Components.sort(
                  OrderBy.localeCompare("Name")
                ).map((c, index) => (
                  <tr key={c.Name}>
                    <td>{index + 1}</td>
                    <td>{c.Name}</td>
                    <td>
                      <Link
                        href={`/management-packs/${c.TargetTypeManagementPackID}/classes/${c.TargetTypeID}`}
                      >
                        <a target="_blank">
                          {c.TargetTypeName} <ExternalLinkIcon />
                        </a>
                      </Link>
                    </td>
                    <td className="center">
                      <CardinalityInfo
                        min={c.MinCardinality}
                        max={c.MaxCardinality}
                      />
                    </td>
                    <td className="table-copy-col">
                      <CopyButton
                        text={c.TargetTypeManagementPackXmlReferenceSample}
                        title="Copier ref. XML du Management Pack"
                      />
                    </td>
                    <td className="table-copy-col">
                      <CopyButton
                        text={c.XmlReferenceSample}
                        title="Copier ref. XML de la relation"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </section>

          <section className="page-content-section liste-elements">
            <h5>Modèles associés (Templates)</h5>

            {typeProjection.Templates && typeProjection.Templates.length > 0 ? (
              <ul>
                {typeProjection.Templates.sort(
                  OrderBy.localeCompare("Name")
                ).map((t, index) => (
                  <li key={t.ID}>
                    <span className="index-label">{index + 1}.</span>
                    <Link
                      href={`/management-packs/${t.ManagementPackID}/templates/${t.ID}`}
                    >
                      <a target="_blank">{t.DisplayName || t.Name}</a>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p>Aucun élément</p>
            )}
          </section>

          {!typeProjection.TargetType.IsAbstract && (
            <>
              <CriteriaQuerySampleForTypeProjection typeProj={typeProjection} />

              <br />

              <CSharpCodeSampleForTypeProjection typeProj={typeProjection} />
            </>
          )}
        </Card.Body>
      </Card>
    </>
  );
}

///////////////////////////////////////////

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const typeProjection = await recupererTypeProjectionParId(
    params.id as string
  );
  return {
    props: {
      id: params.id,
      mp_id: params.mp_id,
      object_type: "typeprojections",
      object_name: typeProjection.Name,
      typeProjection,
    },
  };
};

export const getStaticPaths: GetStaticPaths = async () => {
  const typeProjs = await recupererListeTypesObject("TYPE_PROJ");

  const paths = typeProjs.map(
    (e) => `/management-packs/${e.ManagementPackID}/typeprojections/${e.ID}`
  );

  return {
    paths,
    fallback: false,
  };
};

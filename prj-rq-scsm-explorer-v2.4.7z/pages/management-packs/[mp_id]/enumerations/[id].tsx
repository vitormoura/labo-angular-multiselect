import {
  recupererElementsEnumParId,
  recupererListeTypesObject,
} from "@/lib/static-data-loader";
import { GenericPageProps, IEnumerationItem } from "@/lib/static-data-models";
import { GetStaticPaths, GetStaticProps } from "next";
import { Card, Table, Form } from "react-bootstrap";
import { CopyButton } from "@/components/copy-to-clipboard";
import { BookmarkButton } from "@/components/bookmark-button";
import { useState } from "react";

interface PageProps extends GenericPageProps {
  id: string;
  elements: IEnumerationItem[];
}

export default function PageEnumerationDetails({
  id,
  mp_id,
  elements,
}: PageProps) {
  const root = elements[0];
  const [isCopyMode, setIsCopyMode] = useState(false);

  return (
    <>
      <h1 className="page-title">
        <strong>{root.DisplayName || root.Name}</strong>

        <BookmarkButton
          entityId={root.ID}
          url={`/management-packs/${mp_id}/enumerations/${id}`}
          name={root.Name}
          type="Enumerations"
        />
      </h1>

      <Card className="app-page-content-card">
        <Card.Body>
          <section className="page-content-section">
            <h5>Informations générales</h5>

            <dl>
              <dt>
                Identifiant <CopyButton text={root.ID} />
              </dt>
              <dd>{root.ID}</dd>

              <dt>Nom</dt>
              <dd>{root.Name}</dd>

              <dt>Description</dt>
              <dd>{root.Description || "-"}</dd>
            </dl>
          </section>

          <section className="page-content-section">
            <h5>Éléments de l'enumeration</h5>

            <Form>
              <div className="mb-3">
                <Form.Check
                  name="copyMode"
                  inline
                  label="Tableau"
                  type="radio"
                  onClick={() => setIsCopyMode(false)}
                  defaultChecked={!isCopyMode}
                />
                <Form.Check
                  name="copyMode"
                  inline
                  label="Texte"
                  type="radio"
                  onClick={() => setIsCopyMode(true)}
                  defaultChecked={isCopyMode}
                />
              </div>
            </Form>

            {!isCopyMode && (
              <Table responsive hover size="sm">
                <tbody>
                  {elements.map((e, index) => (
                    <tr key={e.ID}>
                      <td></td>
                      <td
                        style={{
                          paddingLeft: `${(e.Level + 1) * 0.8}rem`,
                          fontWeight: 900 - (e.Level + 1) * 150,
                        }}
                      >
                        {e.DisplayName || e.Name}{" "}
                        {e.ID === root.ID ? "(racine)" : ""}
                      </td>
                      <td>
                        <span className="cnt-id-guid"> {e.ID} </span>{" "}
                        <CopyButton text={e.ID} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            )}

            {isCopyMode && (
              <pre className="cnt-id-guid cnt-xml-code">
                {elements.map((e) => (
                  <>
                    {"\t".repeat(e.Level)}
                    {e.ID} {e.DisplayName || e.Name}
                    {"\n"}
                  </>
                ))}
              </pre>
            )}
          </section>
        </Card.Body>
      </Card>
    </>
  );
}

///////////////////////////////////////////

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const elements = await recupererElementsEnumParId(params.id as string);

  return {
    props: {
      id: params.id,
      mp_id: params.mp_id,
      object_type: "enumerations",
      object_name: elements[0].Name,
      elements,
    },
  };
};

export const getStaticPaths: GetStaticPaths = async () => {
  const enums = await recupererListeTypesObject("ENUM");

  const paths = enums.map(
    (e) => `/management-packs/${e.ManagementPackID}/enumerations/${e.ID}`
  );

  return {
    paths,
    fallback: false,
  };
};

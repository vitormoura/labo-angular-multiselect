import {
  recupererElementsEnumParId,
  recupererGabaritObjetParId,
  recupererListeTypesObject,
} from "@/lib/static-data-loader";
import {
  GenericPageProps,
  IEnumerationItem,
  IObjectTemplate,
} from "@/lib/static-data-models";
import { GetStaticPaths, GetStaticProps } from "next";
import { Card, Table } from "react-bootstrap";
import { CopyButton } from "@/components/copy-to-clipboard";
import { BookmarkButton } from "@/components/bookmark-button";
import { ExternalLinkIcon } from "@/components/external-link-icon";
import Link from "next/link";
import { OrderBy } from "@/lib/ui-utils";

interface PageProps extends GenericPageProps {
  id: string;
  template: IObjectTemplate;
}

export default function PageObjectTemplateDetails({
  id,
  mp_id,
  template,
}: PageProps) {
  return (
    <>
      <h1 className="page-title">
        <strong>{template.DisplayName || template.Name}</strong>

        <BookmarkButton
          entityId={template.ID}
          url={`/management-packs/${mp_id}/templates/${id}`}
          name={template.Name}
          type="Templates"
        />
      </h1>

      <Card className="app-page-content-card">
        <Card.Body>
          <section className="page-content-section">
            <h5>Informations générales</h5>

            <dl>
              <dt>
                Identifiant <CopyButton text={template.ID} />
              </dt>
              <dd>{template.ID}</dd>

              <dt>Nom</dt>
              <dd>{template.Name}</dd>

              <dt>Nom d'affichage</dt>
              <dd>{template.DisplayName || "-"}</dd>

              <dt>Management Pack</dt>
              <dd>
                <Link href={`/management-packs/${template.ManagementPackID}/info`}>
                  <a target="_blank">
                    {template.ManagementPackName} <ExternalLinkIcon />
                  </a>
                </Link>
              </dd>

              {template.TypeProjection && (
                <>
                  <dt>Projection Cible</dt>
                  <dd>
                    <Link
                      href={`/management-packs/${template.TypeProjection.ManagementPackID}/typeprojections/${template.TypeProjectionID}`}
                    >
                      <a target="_blank">
                        {template.TypeProjection.Name} <ExternalLinkIcon />
                      </a>
                    </Link>
                  </dd>
                </>
              )}
            </dl>
          </section>

          <section className="page-content-section">
            <h5>Propriétés pré-remplies</h5>

            {template.Properties && template.Properties.length > 0 ? (
              <>
                <Table responsive hover size="sm">
                  <thead>
                    <tr>
                      <th className="table-index-col">#</th>
                      <th className="table-prop-col-mini">Name</th>
                      <th>Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {template.Properties.map((p, index) => (
                      <tr key={p.ID}>
                        <td>{index + 1}</td>
                        <td className="table-prop-col-mini">
                          {p.PropertyName}
                        </td>
                        <td>
                          {p.EnumValue
                            ? `${
                                p.EnumValue.DisplayName || p.EnumValue.Name
                              } (enum)`
                            : p.Value}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </>
            ) : (
              <p>
                <em>Aucune propriété</em>
              </p>
            )}
          </section>
        </Card.Body>
      </Card>
    </>
  );
}

///////////////////////////////////////////

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const template = await recupererGabaritObjetParId(params.id as string);

  return {
    props: {
      id: params.id,
      mp_id: params.mp_id,
      object_type: "templates",
      object_name: template.Name,
      template,
    },
  };
};

export const getStaticPaths: GetStaticPaths = async () => {
  const templates = await recupererListeTypesObject("TEMPLATE");
  const paths = templates.map(
    (e) => `/management-packs/${e.ManagementPackID}/templates/${e.ID}`
  );

  return {
    paths,
    fallback: false,
  };
};

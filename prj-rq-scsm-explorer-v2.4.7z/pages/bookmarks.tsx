import { Card, Container } from "react-bootstrap";
import Link from "next/link";
import { useEffect, useState } from "react";
import {
  getPersonnalBookmarkCollection,
  IEntityBookmarkDetails,
} from "@/lib/entities-bookmarks";
import groupBy from "lodash/groupBy";

export default function BookmarksPage() {
  const [bookmarks, setBookmarks] = useState({
    length: 0,
    loaded: false,
    items: {} as { [key: string]: IEntityBookmarkDetails[] },
  });

  useEffect(() => {
    getPersonnalBookmarkCollection().then((result) => {
      setBookmarks({
        length: result.length,
        loaded: true,
        items: groupBy(result, "type"),
      });
    });
  }, []);

  let content = <p>loading...</p>;

  if (bookmarks.loaded) {
    if (bookmarks.length > 0) {
      content = (
        <>
          {Object.keys(bookmarks.items).map((type, index) => (
            <section
              className="page-content-section liste-elements"
              key={index}
            >
              <h6>{type}</h6>

              <ul>
                {bookmarks.items[type].map((b, index) => (
                  <li key={b.name}>
                    <span className="index-label">{index + 1}.</span>
                    <Link href={b.url}>
                      <a>{b.name}</a>
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </>
      );
    } else {
        content = <p>Aucun bookmark :(</p>
    }
  }

  return (
    <Container>
      <h1 className="page-title">Bookmarks ({bookmarks.length})</h1>

      <Card className="app-page-content-card">
        <Card.Body>{content}</Card.Body>
      </Card>
    </Container>
  );
}

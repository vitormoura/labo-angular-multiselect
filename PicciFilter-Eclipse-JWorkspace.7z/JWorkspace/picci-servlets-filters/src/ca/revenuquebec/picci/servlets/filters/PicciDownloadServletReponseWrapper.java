package ca.revenuquebec.picci.servlets.filters;

import java.util.HashMap;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

/**
 * Rajoute des traitements manquantes � la classe base HttpServletResponseWrapper 
 * @author RDEV021
 */
public class PicciDownloadServletReponseWrapper extends HttpServletResponseWrapper {

	private HashMap<String, String> _headers = new HashMap<String, String>();
	
	/**
	 * Rajoute un header � la r�ponse HTTP
	 */
	@Override
	public void addHeader(String headerName, String value) {
		super.addHeader(headerName, value);		
		
		_headers.put(headerName, value);
	}
	
	/**
	 * Rajoute un header � la r�ponse HTTP
	 */
	@Override
	public void setHeader(String headerName, String value) {
		this.addHeader(headerName, value);		
	}
	
	/** 
	 * R�cup�re la valeur du header identifi� par le nom donn�
	 * @param headerName
	 * @return
	 */
	public String getHeader(String headerName) {
		return _headers.get(headerName);
	}
	
	/**
	 * R�cup�re la liste des headers ajout�s � requ�te
	 * @return
	 */
	public Set<String> getHeaderList() {
		return _headers.keySet();
	}
			
	/**
	 * Cr�e un nouvel objet PicciDownloadServletReponseWrapper
	 * @param response
	 */
	public PicciDownloadServletReponseWrapper(HttpServletResponse response) {
		super(response);	
	}
}

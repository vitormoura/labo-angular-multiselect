package ca.revenuquebec.picci.servlets.filters;

import java.io.OutputStream;
import java.io.PrintWriter;

public class PicciFilterPrintWriter extends PrintWriter {

	public PicciFilterPrintWriter(OutputStream out) {
		super(out);
	}
}

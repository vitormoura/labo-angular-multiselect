package ca.revenuquebec.picci.servlets.filters;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class PicciDownloadServletRequestWrapper extends HttpServletRequestWrapper {

	@Override
	public String getHeader(String headerName) {
		if(headerName != "User-Agent") {
			return super.getHeader(headerName);
		}
		
		String currentValue = super.getHeader(headerName);
		
		if(currentValue == null) {
			return null;
		}
		
		return currentValue.replaceAll("(?i)gecko", "");		
	}
	
	public String getHeaderOriginal(String headerName) {
		return super.getHeader(headerName);
	}
	
	public PicciDownloadServletRequestWrapper(HttpServletRequest request) {
		super(request);
	}

}

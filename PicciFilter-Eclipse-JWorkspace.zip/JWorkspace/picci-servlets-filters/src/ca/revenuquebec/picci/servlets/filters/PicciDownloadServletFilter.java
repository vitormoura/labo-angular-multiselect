package ca.revenuquebec.picci.servlets.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * Filtre pour corriger le header Content-Disposition des HttpReponses g�n�r�es
 * par d'autres servlets
 */
public class PicciDownloadServletFilter implements Filter {
	private static Logger log = Logger.getLogger(PicciDownloadServletFilter.class);

	/**
	 * Default constructor.
	 */
	public PicciDownloadServletFilter() {

	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		//
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		log.info("servlet filter called");

		try {
			HttpServletRequest httpServletRequest = (HttpServletRequest) request;
			HttpServletResponse httpServletResponse = (HttpServletResponse) response;
			PicciDownloadServletReponseWrapper responseWrapper = new PicciDownloadServletReponseWrapper(
					httpServletResponse);
			PicciDownloadServletRequestWrapper httpServletRequestWrapper = new PicciDownloadServletRequestWrapper(
					httpServletRequest);

			//
			// Changements avant l'ex�cution du Servlet
			//
			
			log.info("running servlet code for " + httpServletRequest.getRequestURI());
			log.info("request user-agent: " + httpServletRequestWrapper.getHeaderOriginal("User-Agent"));
			log.info("new request user-agent string: " + httpServletRequestWrapper.getHeader("User-Agent"));

			// On �x�cute le servlet principal
			chain.doFilter(httpServletRequestWrapper, responseWrapper); 

						
			//
			// Changements apr�s l'ex�cution du Servlet
			//
			
			/*
			log.info("add custom header PicciServlets");

			// On rajoute un header pour indiquer qu'on est pass� par ce filtre
			responseWrapper.addHeader("PicciServlets-DownloadServletFilterApplied", "1");
			
			log.info("check header Content-Disposition");

			// Enfin, on v�rifie s'il y a un Header "Content-Disposition"
			if (responseWrapper.containsHeader("Content-Disposition")) {
				String currentContentDispo = responseWrapper.getHeader("Content-Disposition");

				if (currentContentDispo == null) {
					log.info("Content-Disposition header is null");
					return;
				}

				///////////////////////////////////////////////////////////////////////////////////

				// On v�rifie si la valeur est bonne
				if (!currentContentDispo.contains("utf8")) {
					log.info("no Content-Disposition header does not contains invalid values");
					return;
				}

				log.info("changing invalid Content-Disposition header: " + currentContentDispo);

				// Sinon, on la corrige rempla�ant la valeur courante
				String changedContentDispo = currentContentDispo.replaceAll("utf8", "utf-8");

				httpServletResponse.setHeader("Content-Disposition", changedContentDispo);

				log.info("Content-Disposition header changed :" + changedContentDispo);

				//////////////////////////////////////////////////////////////////////////////////
			} else {
				log.info("no Content-Disposition header found");
			}
			// */

		} catch (Exception ex) {
			log.error("filter error:" + ex.getMessage());

			System.err.print(ex.getMessage());
			ex.printStackTrace();
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {

		String configFilePath = fConfig.getInitParameter("log4j-config-path");
		
		if (configFilePath != null && configFilePath.trim().length() > 2) {
			PropertyConfigurator.configure(configFilePath.trim());
		}
	}
}
